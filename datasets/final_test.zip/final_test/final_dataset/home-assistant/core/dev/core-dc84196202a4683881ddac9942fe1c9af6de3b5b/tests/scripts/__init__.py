"""Tests for the scripts."""

from .cli import main

main(as_module=True)

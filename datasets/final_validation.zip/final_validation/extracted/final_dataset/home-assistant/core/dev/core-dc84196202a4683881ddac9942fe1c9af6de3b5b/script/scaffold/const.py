"""Constants for scaffolding."""
from pathlib import Path

COMPONENT_DIR = Path("homeassistant/components")
TESTS_DIR = Path("tests/components")

"""Home Assistant scripts."""

"""Layers that can merge several inputs into one."""

from tensorflow.keras.layers import Add
from tensorflow.keras.layers import Subtract
from tensorflow.keras.layers import Multiply
from tensorflow.keras.layers import Average
from tensorflow.keras.layers import Maximum
from tensorflow.keras.layers import Minimum
from tensorflow.keras.layers import Concatenate
from tensorflow.keras.layers import Dot
from tensorflow.keras.layers import add
from tensorflow.keras.layers import subtract
from tensorflow.keras.layers import multiply
from tensorflow.keras.layers import average
from tensorflow.keras.layers import maximum
from tensorflow.keras.layers import minimum
from tensorflow.keras.layers import concatenate
from tensorflow.keras.layers import dot

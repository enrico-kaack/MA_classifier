"""Training-related part of the Keras engine."""
from tensorflow.keras import Model

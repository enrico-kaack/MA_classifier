"""Contains the base Layer class, from which all layers inherit."""
from tensorflow.keras.layers import Layer
from tensorflow.keras.layers import InputSpec

import torch


torch.cuda.manual_seed_all(0)
torch.cuda.manual_seed(1007)

"""
HTTPie - a CLI, cURL-like tool for humans.

"""

__version__ = '2.3.0-dev'
__author__ = 'Jakub Roztocil'
__licence__ = 'BSD'

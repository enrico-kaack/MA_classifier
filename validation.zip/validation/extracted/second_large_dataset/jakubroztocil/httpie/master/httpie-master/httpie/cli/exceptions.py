class ParseError(Exception):
    pass

"""Translation helper scripts."""

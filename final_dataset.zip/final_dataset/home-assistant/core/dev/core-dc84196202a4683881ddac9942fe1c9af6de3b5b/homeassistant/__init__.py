"""Init file for Home Assistant."""

"""
HTTPie: command-line HTTP client for the API era.

"""

__version__ = '2.3.0-dev'
__author__ = 'Jakub Roztocil'
__licence__ = 'BSD'
